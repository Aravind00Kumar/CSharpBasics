﻿using System;

namespace GameLibrary
{
    public class Class1
    {
    }
}
