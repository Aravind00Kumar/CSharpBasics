using System;

namespace DayOne
{
  public class ClassOne
  {
     public static void Main()
     {
        Console.WriteLine("Hello World!");
        Console.ReadKey();
     }
  }

}