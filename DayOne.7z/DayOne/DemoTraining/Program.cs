﻿using System;
using System.IO;
using DemoTraining;
namespace DemoTraining2
{
    class Program
    {
        static void Main()
        {
            //BasicsOne.Execute();
            //BasicsTwo.ForLoop();
            //BasicsTwo.WhileLoop();
            //BasicsThree.Execute();
            BasicsClass.Execute();

            int XMax = 120;
            int YMax = 30;
            Console.SetWindowSize(XMax, YMax);
            //Flight fl = new Flight();
            //fl.setX(59);
            //fl.y = 28;
            //fl.Z = 10;
            //fl.Display();


            //Flight f2 = new Flight();
            //f2.setX(59);
            //f2.y = 25;
            //f2.Display();

            char ch = ' ';
            Flight flightObj = new Flight(XMax / 2, YMax - 2);
            //Flight flightObj2 = new Flight();

            //flightObj.Init(XMax / 2, YMax - 2);
            flightObj.Display();
            do {
                ch  = Console.ReadKey(true).KeyChar;
                if (ch == 'a') {
                    flightObj.MoveLeft();
                }
                if (ch == 'l')
                {
                    flightObj.MoveRight();
                }
                flightObj.Display();

            } while (ch!='e');


            Console.ReadKey();
        }


        //Field
        //Method
        //Property
        
    }

   
}
