﻿//
open *Developer Command Prompt for VS 2019 from start menu*

Code compilation using C#: csc program.cs -target:exe
Disassembling the library or exe : ildasm program.exe /out="program.il"
Assembling the library or exe : ilasm program.il /X64

 


